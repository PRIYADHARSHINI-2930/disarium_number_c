/*disarium number without pow*/
#include <stdio.h>
int power(int b,int p)
{
    int res=1;
    for(int i=1;i<=p;i++)
    {
        res=res*b;
    }
    return res;
}

int main()
{
    int n,i,c,r,result;
    scanf("%d",&n);
    int k=n;
    int temp=n;
    while(n>0)
    {
        n=n/10;
        c++;
    }
    while(k>0)
    {
    
        r=k%10;
        result=result+power(r,c--);
        k=k/10;
    }
    printf(temp==result?"Yes":"No");

    return 0;
}
